# Morse Code Module

## About
* The morse code module enables users to decrypt and encrypt morse code

## Features
### `morsecode.encrypt()`
* Rerurns a translation into morse code
* 1st argument: a senence/word you want to translate to morse code

### `morsecode.decrypt()`
* Returns a translation from morse code
* 1st argument: morse code you want to translate back

## Credits
* Will ward